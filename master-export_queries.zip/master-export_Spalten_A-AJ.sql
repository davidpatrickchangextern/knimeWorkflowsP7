use wilson;


/*
------ 1. START: mirgrate constants to sql tables ------- 
all temporary tables below exists only as hardcoded constants in wilson code
*/

/* DEPARTMENTS */
/* Wilson::Clients::Config::DEPARTMENTS.each {|id, config| puts "(#{id}, '#{config[:token]}', '#{config[:name]}'),"}; nil */
DROP TEMPORARY TABLE IF EXISTS tmpDepartments;
CREATE TEMPORARY TABLE tmpDepartments
(
id INT NOT NULL PRIMARY KEY,
token VARCHAR(255),
name VARCHAR(255)
); 
INSERT INTO tmpDepartments 
(id, token, name)
VALUES
(1, 'M', 'Marketing'),
(2, 'R', 'Redaktion'),
(3, 'Audiotex', 'Audiotex'),
(4, 'DIS', 'Distribution'),
(5, 'DIV', 'Diverse'),
(6, 'EXT', 'Extern'),
(7, 'GF', 'Geschäftsführung'),
(8, 'HR', 'Human Ressources'),
(9, 'K1C', 'kabel eins Classics'),
(10, 'Mobile', 'Mobile'),
(11, 'Online-Marketing', 'Online-Marketing'),
(12, 'P7F', 'ProSieben Fun'),
(13, 'P7M Austria', 'ProSieben MAXX Austria'),
(14, 'PR', 'Public Relations'),
(15, 'PR7.de', 'ProSieben.de'),
(16, 'S1E', 'SAT.1 Emotions'),
(17, 'S1G Österreich', 'SAT.1 Gold Österreich'),
(18, 'Sales', 'Sales'),
(19, 'Sales Marketing', 'Sales Marketing'),
(20, 'Strat. Marketing', 'Strategic Marketing'),
(21, 'Online', 'Online'),
(22, 'Mobile Access', 'Mobile Access'),
(23, 'ran Online', 'ran Online'),
(24, 'Telefonansagen', 'Telefonansagen'),
(25, 'Teletext', 'Teletext'),
(26, 'Online-Redaktion', 'Online-Redaktion'),
(27, 'RedButton', 'RedButton'),
(28, 'U-Kom', 'U-Kom'),
(29, 'Sonstiges', 'Sonstiges'),
(30, 'Digital Content', 'Digital Content');


/* SUB_DEPARTMENTS */
/* Wilson::Clients::Config::SUB_DEPARTMENTS.each {|id, config| puts "(#{id}, '#{config[:name]}'),"}; nil */
DROP TEMPORARY TABLE IF EXISTS tmpSubDepartments;
CREATE TEMPORARY TABLE tmpSubDepartments
(
id INT NOT NULL PRIMARY KEY,
name VARCHAR(255)
); 
INSERT INTO tmpSubDepartments 
(id, name)
VALUES
(1, 'Brand'),
(2, 'Entertainment'),
(3, 'Infotainment'),
(4, 'Fiction-Serie'),
(5, 'Fiction-Spielfilm'),
(6, 'On Ground'),
(7, 'Sport'),
(8, 'n. v.'),
(9, 'Reality'),
(10, 'Unterhaltung / Comedy'),
(11, 'Unterhaltung / Show'),
(12, 'Serie AP'),
(13, 'Serie Lizenz'),
(14, 'Spielfilm AP'),
(15, 'Spielfilm Lizenz'),
(16, 'Reality Daytime'),
(17, 'Reality Prime-Time'),
(18, 'Daytime'),
(19, 'Factual'),
(20, 'Food'),
(99, '---');


/* CM_STATUS */
/* Wilson::Projects::Config::CM_STATUS.each {|id, config| puts "(#{id}, '#{I18n.t("projects.cm_status.#{config[:name]}")}'),"}; nil */
DROP TEMPORARY TABLE IF EXISTS tmpCmStatus;
CREATE TEMPORARY TABLE tmpCmStatus
(
id INT NOT NULL PRIMARY KEY,
name VARCHAR(255)
); 
INSERT INTO tmpCmStatus 
(id, name)
VALUES
(0, 'keiner'),
(1, 'geplant'),
(2, 'aktiv (gates)'),
(3, 'inaktiv'),
(4, 'abgesagt'),
(5, 'abgeschlossen'),
(10, 'Altprojekt');


/* Project-TYPE_OF */
/* Wilson::Projects::Config::TYPE_OF.each {|id, config| puts "(#{id}, '#{I18n.t("projects.type_of.#{config[:name]}")}'),"}; nil */
DROP TEMPORARY TABLE IF EXISTS tmpProjectTypes;
CREATE TEMPORARY TABLE tmpProjectTypes
(
id INT NOT NULL PRIMARY KEY,
name VARCHAR(255)
); 
INSERT INTO tmpProjectTypes 
(id, name)
VALUES
(1, 'Kampagne'),
(2, 'Formatverpackung'),
(5, 'Brand'),
(8, 'B2B'),
(14, 'Digitalkampagne'),
(30, 'sonstiges');


/* CAMPAIGN_TYPE */
/* Wilson::Projects::Config::CAMPAIGN_TYPE.each {|id, config| puts "(#{id}, '#{I18n.t("projects.campaign_type.#{config[:name]}")}'),"}; nil */
DROP TEMPORARY TABLE IF EXISTS tmpCampaignTypes;
CREATE TEMPORARY TABLE tmpCampaignTypes
(
id INT NOT NULL PRIMARY KEY,
name VARCHAR(255)
); 
INSERT INTO tmpCampaignTypes 
(id, name)
VALUES
(1, 'Ankündigung'),
(5, 'Begleitung'),
(10, 'Einzelkampagne'),
(14, 'Bundle');


/* DAY_PARTS */
/* Wilson::Projects::Config::DAY_PARTS.each {|id, config| puts "(#{id}, '#{I18n.t("projects.day_parts.#{config}")}'),"}; nil */
DROP TEMPORARY TABLE IF EXISTS tmpDayParts;
CREATE TEMPORARY TABLE tmpDayParts
(
id INT NOT NULL PRIMARY KEY,
name VARCHAR(255)
); 
INSERT INTO tmpDayParts 
(id, name)
VALUES
(1, 'Keine'),
(2, 'Prime'),
(3, 'Late Prime'),
(4, 'Access'),
(5, 'Daytime');


/* FORMAT_TYPES */
/* Wilson::Projects::Config::FORMAT_TYPES.each {|id, config| puts "(#{id}, '#{I18n.t("projects.format_types.#{config}")}'),"}; nil */
DROP TEMPORARY TABLE IF EXISTS tmpFormatTypes;
CREATE TEMPORARY TABLE tmpFormatTypes
(
id INT NOT NULL PRIMARY KEY,
name VARCHAR(255)
); 
INSERT INTO tmpFormatTypes 
(id, name)
VALUES
(1, 'Keine'),
(2, 'Lizenz'),
(3, 'Eigenproduktion');


/* DECIDER */
/* Wilson::Projects::Config::DECIDER.each {|id, config| puts "(#{id}, '#{I18n.t("projects.decider.#{config[:name]}")}'),"}; nil */
DROP TEMPORARY TABLE IF EXISTS tmpDeciders;
CREATE TEMPORARY TABLE tmpDeciders
(
id INT NOT NULL PRIMARY KEY,
name VARCHAR(255)
); 
INSERT INTO tmpDeciders 
(id, name)
VALUES
(1, 'GF TVD'),
(5, 'Senderchef'),
(9, 'Marketingleitung'),
(14, 'Marketing Manager'),
(19, 'CS / Operations'),
(24, 'Producer'),
(29, 'Producer');


/* CS_STATUS */
/* Wilson::Projects::Config::CS_STATUS.each {|id, config| puts "(#{id}, '#{I18n.t("projects.cs_status.#{config[:name]}")}'),"}; nil */
DROP TEMPORARY TABLE IF EXISTS tmpCsStatus;
CREATE TEMPORARY TABLE tmpCsStatus
(
id INT NOT NULL PRIMARY KEY,
name VARCHAR(255)
); 
INSERT INTO tmpCsStatus
(id, name)
VALUES
(0, 'keiner'),
(1, 'in Planung'),
(3, 'in Produktion'),
(4, 'abgesagt'),
(5, 'on hold'),
(6, 'NEU'),
(15, 'abgeschlossen');


/* INTERVAL */
/* Wilson::Projects::Config::INTERVAL.each {|id, config| puts "(#{id}, '#{I18n.t("projects.interval.#{config[:name]}")}'),"}; nil */
DROP TEMPORARY TABLE IF EXISTS tmpIntervals;
CREATE TEMPORARY TABLE tmpIntervals
(
id INT NOT NULL PRIMARY KEY,
name VARCHAR(255)
); 
INSERT INTO tmpIntervals
(id, name)
VALUES
(1, 'wöchentlich'),
(2, 'alle 2 Wochen'),
(4, 'alle 4 Wochen');


/* EFFORTS_DIFF_REASON */
/* Wilson::Projects::Config::EFFORTS_DIFF_REASON.each {|id, config| puts "(#{id}, '#{I18n.t("projects.efforts_diff_reason.#{config[:name]}")}'),"}; nil */
DROP TEMPORARY TABLE IF EXISTS tmpEffortsDiffReasons;
CREATE TEMPORARY TABLE tmpEffortsDiffReasons
(
id INT NOT NULL PRIMARY KEY,
name VARCHAR(255)
); 
INSERT INTO tmpEffortsDiffReasons
(id, name)
VALUES
(0, '-'),
(1, 'Zusatzelemente'),
(5, 'Budgetaufstockung'),
(10, 'Korrekturschleifen'),
(15, 'Strategische Umentscheidung'),
(20, 'Materialanlieferung / Leerlaufschichten'),
(25, 'Kurzfristige Umplanung intern/extern'),
(30, 'Produktion aufwändiger als im Konzept vorgesehen');








/*
------ 2. START MasterExport columns A-AJ ------- 
*/

SELECT DISTINCT
	/*Bereich*/
	tmpDepartments.token AS 'department_name',
    /*Kunde*/
    clients.token AS 'client_token', 
    /*Projekt-Status*/
    tmpCmStatus.name AS 'project_status_name',
	/*Auftragsnummer*/
    p.project_number_intern,
	/*Innen-Auftragsnummer*/
    p.project_number_client,
    /*Titel*/
    p.title,
    /*Einstart (Auswertung)*/
    p.project_start_date,
    /*Start Format*/
    p.program_start_date,
    /*Projektart*/
    tmpProjectTypes.name AS 'project_type_name',
    /*Kampagnentyp*/
	tmpCampaignTypes.name AS 'campaign_type_name',
    /*Klasse*/
    p.complexity,
    /*Timeslot*/
    tmpDayParts.name AS 'day_part_name',
	/*Formatart*/
	tmpFormatTypes.name AS 'format_type_name',
	/*Unterbereich*/
    tmpSubDepartments.name AS 'sub_department_name',
    /*Entscheider*/
    tmpDeciders.name AS 'decider_name',
    /*Marketing Manager*/
    CONCAT(central_marketing_users.last_name, ", ", central_marketing_users.first_name) AS 'marketing_manager_name',
    /*Projekt Manager*/
    CONCAT(project_manager_users.last_name, ", ", project_manager_users.first_name) AS 'project_manager_name',
    /*Squad Lead*/
    CONCAT(creative_lead_users.last_name, ", ", creative_lead_users.first_name) AS 'creative_lead_name',
    /*Start-Datum (berechnet)*/
    "!--TBD--!" AS "start_date",
    /*End-Datum (berechnet)*/
    "!--TBD--!" AS "end_date",
    /*Marke*/
    clients.brand AS "brand",
	/*Team-Art*/
    team_tags.name AS "team_type_name",
    /*Hauptaufwand*/
    IF(p.production_int_ext = 2, 'extern', 'intern') AS "production_type",
    /*Unit*/
    "!--no project column--!" AS "unit",
    /*Start Kampagne*/
    p.campaign_start_date,
	/*Einstart*/
    p.generic_start_date,
    /*CS-Status*/
    tmpCsStatus.name AS "cs_status_name",
    /*Produktionspakete*/
    p.production_package_quantity,
    /*Taktung*/
    tmpIntervals.name AS "interval_name",
    /*Grund fuer Abweichung*/
    tmpEffortsDiffReasons.name AS "reason_for_difference_name",
    /*Bemerkung (Grund fuer Abweichung)*/
    p.planned_efforts_comment,
    /*Erstellt am*/
    p.created_at,
    /*Geändert am*/
    p.updated_at,
    /*Format-Titel*/
    project_formats.title AS "format_title",
    /*Format-ID*/
    project_formats.id AS "format_id",
    /*Wilson-ID / PRIMARY KEY*/
    p.id
FROM projects AS p
LEFT JOIN tmpDepartments ON p.department = tmpDepartments.id 
LEFT JOIN clients ON p.client_id = clients.id
LEFT JOIN tmpCmStatus ON IFNULL(p.cm_status, 0) = tmpCmStatus.id
LEFT JOIN tmpProjectTypes ON p.type_of = tmpProjectTypes.id
LEFT JOIN tmpCampaignTypes ON p.campaign_type = tmpCampaignTypes.id
LEFT JOIN tmpDayParts ON p.day_part = tmpDayParts.id
LEFT JOIN tmpFormatTypes ON p.format_type = tmpFormatTypes.id
LEFT JOIN tmpSubDepartments ON p.sub_department = tmpSubDepartments.id 
LEFT JOIN tmpDeciders ON p.decider = tmpDeciders.id 
LEFT JOIN users AS central_marketing_users ON p.cm_user_id = central_marketing_users.id
LEFT JOIN users AS project_manager_users ON p.owner_user_id = project_manager_users.id
LEFT JOIN users AS creative_lead_users ON p.creative_lead_user_id = creative_lead_users.id
LEFT JOIN tags AS team_tags ON team_tags.id = (
	SELECT taggings.tag_id FROM taggings 
    WHERE taggings.taggable_type = 'Project' 
    AND taggings.taggable_id = p.id 
    AND taggings.context = 'team_type_tags' 
    LIMIT 1 /*Workaround: technicaly there could be more then one mapped tag-record via taggings n:m-table, but we allow only a single assignment via UI*/
)
LEFT JOIN tmpCsStatus ON IFNULL(p.cs_status, 0) = tmpCsStatus.id
LEFT JOIN tmpIntervals ON p.interval = tmpIntervals.id
LEFT JOIN tmpEffortsDiffReasons ON p.reason_for_difference = tmpEffortsDiffReasons.id
LEFT JOIN project_formats ON p.format_id = project_formats.id





/*
------ 3. START Restrict results on 2020 ------- 
Either the project_start_date is in given year
or the project has planned_efforts in given year
*/

LEFT JOIN prepared_efforts 
	ON prepared_efforts.project_id = p.id
	AND prepared_efforts.effort_type IN ('planned_theoretically')
    AND prepared_efforts.date BETWEEN "2020-01-01" AND "2020-12-31"
WHERE
(
	prepared_efforts.hours IS NOT NULL
    OR p.project_start_date BETWEEN "2020-01-01" AND "2020-12-31"
)    

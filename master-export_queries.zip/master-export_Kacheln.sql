use wilson;

/*
via n:m-mapping tabelle 'project_traits_projects' wird der projects-Datensatz mit den project_traits (a.k.a Kacheln) verknüpft.
jeder project_traits-datensatz kann mehrere Aufwände (project_trait_efforts), für unterschiedliche 'effort_units' haben.
project_trait_efforts werden für intern oder extern vergebene Projekte separat konfiguriert (project_trait_efforts.effort_type)
*/

SELECT
p.id,
traits.name AS "trait_name", /*Kachel-Name*/
effort_units.name AS "unit_name",
IF(p.production_package_quantity IS NULL, 1, p.production_package_quantity) AS production_package_quantity,
ROUND(
	SUM(
		/*Der Aufwand je Kachel multipliziert sich mit der 'production_package_quantity' der projects */
		(trait_efforts.hours*IF(p.production_package_quantity IS NULL, 1, p.production_package_quantity))
	)/8 /*Die Stunden werden auf Personenttage umgerechnet*/
	,2
) AS effort_by_quantity
FROM projects AS p
LEFT JOIN project_traits_projects AS trait_mappings ON trait_mappings.project_id = p.id
INNER JOIN project_traits AS traits ON traits.id = trait_mappings.project_trait_id
/*FK ist hier der key!*/
INNER JOIN project_trait_efforts AS trait_efforts ON trait_efforts.project_trait_key = traits.key
INNER JOIN effort_units ON effort_units.id = trait_efforts.unit_id
/*Wenn das Projekt als extern makrkiert ist (production_int_ext = 2), verwenden wir nur die externen trait_efforts (trait_efforts.effort_type = 2)*/
WHERE trait_efforts.effort_type = IF(p.production_int_ext = 2, 2, 1)
GROUP BY p.id, trait_name, unit_name;



/* 

query for daily recreation of prepared_efforts

*/


SET TRANSACTION ISOLATION LEVEL READ COMMITTED;
BEGIN;
TRUNCATE TABLE prepared_efforts;
INSERT INTO prepared_efforts (SELECT * FROM (
  SELECT
      p.client_id AS 'client_id',
      e.project_id AS 'project_id',
      w.date AS "date",
     (CASE
          WHEN e.type_of = 9 THEN 'absence'
          WHEN e.type_of = 10 THEN 'other'
          #the whole workday is 8h absence (independent if an effort-record with 8h absence exists or not)
          WHEN w.status = 15 THEN 'absence'
          ELSE 'existing'
      END) AS 'effort_type',
      (CASE
        WHEN e.effort_unit_id IS NOT NULL THEN e.effort_unit_id
        ELSE w.effort_unit_id
      END) AS 'unit_id',
      SUM(
          (CASE
              #Could be that no effort-record exists for a workday with absence-status!
              WHEN w.status = 15 THEN 8
              ELSE e.amount
          END)
      ) AS 'hours'
  FROM workdays AS w
      LEFT JOIN efforts AS e ON w.id = e.workday_id
      LEFT JOIN projects AS p ON p.id = e.project_id
  WHERE w.effort_unit_id IS NOT NULL #there are some inconsistent records in DB without an unit_id or without a status
  AND w.status IS NOT NULL
  GROUP BY effort_type, unit_id, client_id, project_id, date
  HAVING hours >= 0 #remove all results with valid workdays (with status != absent) but no related efforts

  UNION ALL

  /* returns by system created (planned) efforts for each unit */
  SELECT
      p.client_id AS "client_id",
      pe.project_id AS 'project_id',
      pe.date AS "date",
	          (CASE
        WHEN pe.type_of = 1 THEN 'planned_inhouse'
        WHEN pe.type_of = 2 THEN 'planned_outsourced'
        WHEN pe.type_of = 3 THEN 'planned_theoretically'
      END) AS 'effort_type',
      pe.effort_unit_id AS "unit_id",
      SUM(pe.amount) AS "hours"
  FROM projects AS p
      INNER JOIN planned_efforts AS pe ON pe.project_id = p.id
  GROUP BY effort_type, unit_id, client_id, project_id, date

  UNION ALL

  /* returns by user created (detail planned) efforts for each unit */
  SELECT
      p.client_id AS "client_id",
      ct.timeable_id AS 'project_id',
      cte.date AS "date",
	          (CASE
        WHEN ct.outsourced = 1 THEN 'detail_planned_outsourced'
        ELSE 'detail_planned_inhouse'
      END) AS 'effort_type',
      ct.sub_type AS "unit_id",
      SUM(cte.hours) AS "hours"
  FROM projects AS p
      INNER JOIN calendar_times AS ct ON ct.timeable_id = p.id AND ct.timeable_type = "Project"
      INNER JOIN calendar_time_efforts AS cte ON cte.calendar_time_id = ct.id
  GROUP BY effort_type, unit_id, client_id, project_id, date

  ORDER BY date, client_id, effort_type, unit_id, project_id
) AS baseQuery);
COMMIT;
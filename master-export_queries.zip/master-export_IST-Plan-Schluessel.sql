use wilson;

/* --- schema of prepared_efforts table ---
* `client_id`: reference to clients.id
* `project_id`: 'existing'-efforts and all kind of 'planned'-efforts always have a reference to projects.id
* `date`: date of effort
* `effort_type`:
* `unit_id`: reference to effort_units.id
* `hours`: sum of the records based on hours
*/

/* --- effort_types ---
* absence: absences by users (not relevant for MasterExport)
* other: non-project releated efforts by users (not relevant for MasterExport)
* existing: project releated efforts by users (IST-Aufwände)
* planned_inhouse: Schluessel intern
* planned_outsourced: Schlüssel extern
* planned_theoretically: Schlüssel theoretisch
* detail_planned_inhouse: Plan intern
* detail_planned_outsourced: Plan extern
*/




/* Bsp: Gib mir alle Pro7 IST-Aufwaende in der PJM-Unit fuer jede KW */
SET @pjm_unit_id = (SELECT id FROM effort_units WHERE name = 'PJM' LIMIT 1);
SET @pro7_client_id = (SELECT id FROM clients WHERE token = 'PR7' LIMIT 1);

SELECT
	SUM(hours) AS hours_per_week,
    YEARWEEK(date) AS year_week
FROM prepared_efforts
WHERE client_id = @pro7_client_id
AND unit_id = @pjm_unit_id
GROUP BY year_week


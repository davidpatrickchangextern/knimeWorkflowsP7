use wilson; 


/* 
this table holds already by effort_unit sumerized values
splited by outsourced TRUE/FALSE
*/

/* freeze per unit */
SELECT
	p.id,
    freeze.outsourced,
    freeze.hours,
    unit.name AS effort_unit_name
FROM projects AS p
LEFT JOIN project_effort_freezes AS freeze ON freeze.project_id = p.id
INNER JOIN effort_units AS unit ON freeze.effort_unit_id = unit.id
ORDER BY p.id;


/* freeze sum of projects independet of effort_units, splited by outsourced*/
SELECT
	p.id,
    freeze.outsourced,
    SUM(freeze.hours) AS hours
FROM projects AS p
LEFT JOIN project_effort_freezes AS freeze ON freeze.project_id = p.id
GROUP BY p.id, freeze.outsourced;


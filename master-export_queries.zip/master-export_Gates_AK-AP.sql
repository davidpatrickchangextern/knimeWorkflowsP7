use wilson;

/* GateType exists only as constant */

/* GateType.active.each {|gate_type| puts "(#{gate_type.id}, '#{gate_type.name}'),"}; nil */
DROP TEMPORARY TABLE IF EXISTS tmpGateTypes;
CREATE TEMPORARY TABLE tmpGateTypes
(
id INT NOT NULL PRIMARY KEY,
name VARCHAR(255)
); 
INSERT INTO tmpGateTypes
(id, name)
VALUES
(1, 'Commitment Sheet'),
(5, 'Briefing'),
(12, 'Konzept'),
(15, 'Produktion'),
(16, 'DU Plakat'),
(17, 'DU Anzeige');



/* 
a project can have more than one gate-record of the same gate-type 
we take the last/latest active gate for MasterExport
Note: gates.date-column is of type timestamp. why ever.
*/

SELECT
p.id,
/* Commitment Sheet (Gate) */
(SELECT 
	DATE(gates.date)
    FROM gates 
    WHERE gates.type_of = 1 /*PK of tmpGateTypes */
    AND gates.project_id = p.id 
    AND gates.active = true 
    ORDER BY date DESC 
    LIMIT 1
) AS "commitment_sheet_gate_date",

/* Briefing (Gate) */
(SELECT 
	DATE(gates.date)
    FROM gates 
    WHERE gates.type_of = 5  /*PK of tmpGateTypes */
    AND gates.project_id = p.id 
    AND gates.active = true 
    ORDER BY date DESC 
    LIMIT 1
) AS "briefing_gate_date"

/* 
.
.
.
same stuff for other GateTypes 

*/

FROM projects AS p;




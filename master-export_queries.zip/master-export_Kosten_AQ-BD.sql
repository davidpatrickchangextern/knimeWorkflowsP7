use wilson;

/* PLANNED_COSTS_CATEGORY exists only as constant */
/* Wilson::Projects::Config::PLANNED_COSTS_CATEGORY.each {|id, config| puts "(#{id}, '#{config[:category_class]}', '#{I18n.t("planned_costs.categories.#{config[:name]}")}'),"}; nil */
DROP TEMPORARY TABLE IF EXISTS tmpPlannedCostsCategories;
CREATE TEMPORARY TABLE tmpPlannedCostsCategories
(
id INT NOT NULL PRIMARY KEY,
category_class VARCHAR(255), /* not relevant */
name VARCHAR(255)
); 
INSERT INTO tmpPlannedCostsCategories 
(id, category_class, name)
VALUES
(0, '0', 'Dreh/Shooting'),
(5, '0', 'Design'),
(10, '0', 'OnAir'),
(15, '0', 'Print Produktionskosten'),
(16, '0', 'Print Spitzenausgleich'),
(20, '0', 'Online Produktionskosten'),
(21, '0', 'Online Spitzenausgleich'),
(25, '0', 'Travel und Catering'),
(30, '0', 'Kosten bei internen Gesellschaften'),
(35, '0', 'sonstige Kosten'),
(40, '0', 'Media'),
(100, '5', 'Dreh/Shooting'),
(105, '5', 'Design'),
(110, '5', 'Schnitt'),
(115, '5', 'Kosten bei internen Gesellschaften'),
(120, '5', 'sonstige Kosten'),
(140, '5', 'Media'),
(200, '10', 'Dreh/Shooting'),
(205, '10', 'Design'),
(210, '10', 'Schnitt'),
(215, '10', 'Print Produktionskosten'),
(216, '10', 'Print Spitzenausgleich'),
(220, '10', 'Sprecher'),
(225, '10', 'Konzeption'),
(230, '10', 'Kosten bei internen Gesellschaften'),
(235, '10', 'sonstige Kosten'),
(240, '10', 'Media'),
(250, '10', 'Online Produktionskosten'),
(260, '10', 'Online Spitzenausgleich');



/* 
for MasterExport, we map the PlannedCostsCategories with the same name (e.g. ID 0, 100 and 200) into the same CSV column.
therefor ignoring the PlannedCostsCategories.id on grouping the results is important. We group on the equal PlannedCostsCategories.name
*/


SET @master_export_year = 2020; /* use only planned_costs of given year */

SELECT 
p.id,
tmpPlannedCostsCategories.name AS 'cost_category_name',
SUM(IFNULL(planned_costs.amount, 0)) AS 'sum_of_category'
FROM projects AS p
LEFT JOIN planned_costs ON planned_costs.project_id = p.id AND planned_costs.year = @master_export_year
INNER JOIN tmpPlannedCostsCategories ON tmpPlannedCostsCategories.id = planned_costs.category
GROUP BY p.id, cost_category_name
ORDER BY p.id, cost_category_name;





